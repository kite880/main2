import requests
from bs4 import BeautifulSoup
import openai
import pandas as pd
import time

# API-ключ от OpenAI GPT
openai.api_key = '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'

def read_urls_from_file(file_path):
    with open(file_path, 'r') as file:
        urls = [line.strip() for line in file.readlines()]
    return urls

def parse_client_info(urls):
    # Создаем DataFrame для хранения данных
    data = pd.DataFrame(columns=["Имя клиента", "Место работы", "Ссылка на фото", "Оригинальный текст", "Переведенный текст"])

    for url in urls:
        # Отправляем GET-запрос на страницу
        response = requests.get(url)

        # Проверяем успешность запроса
        if response.status_code == 200:
            # Используем BeautifulSoup для парсинга HTML
            soup = BeautifulSoup(response.text, 'html.parser')

            # Извлекаем имя из тега h1 с классом headline
            client_name_element = soup.find('h1', {'class': 'headline'})
            
            if client_name_element:
                client_name = client_name_element.text.strip()
            else:
                client_name = "Не найдено"

            # Извлекаем место работы (позицию) из тега h2 с классом secondary-title
            position_element = soup.find('h2', {'class': 'secondary-title'})
            
            if position_element:
                position = position_element.text.strip()
            else:
                position = "Не найдено"

            # Извлекаем ссылку на фото из тега img с классом fix-layout-shift
            photo_element = soup.find('img', {'class': 'fix-layout-shift'})
            
            if photo_element and 'src' in photo_element.attrs:
                photo_url = photo_element['src']
            else:
                photo_url = "Не найдено"

            # Извлекаем текст из всех тегов <p>
            paragraphs = soup.find_all('p')
            all_text = ' '.join([p.get_text(strip=True) for p in paragraphs[:-1]])

            # Генерируем переведенный текст с помощью GPT
            translated_text = translate_text_with_gpt(all_text, client_name)
            
            print(f"Имя клиента: {client_name}")
            print(f"Место работы: {position}")
            print(f"Ссылка на фото: {photo_url}")
            print(f"Переведенный текст: {translated_text}")

            # Добавляем данные в DataFrame
            data.loc[data.shape[0]] = {
                "Имя клиента": client_name,
                "Место работы": position,
                "Ссылка на фото": photo_url,
                "Оригинальный текст": all_text,
                "Переведенный текст": translated_text
            }

        else:
            print(f"Ошибка при получении страницы. Код ошибки: {response.status_code}")

    # Сохраняем DataFrame в Excel
    data.to_excel("output_data.xlsx", index=False)

def translate_text_with_gpt(text, client_name, target_language='ru'):
    # Задаем параметры запроса к GPT-3.5 Turbo
    response = openai.Completion.create(
        engine="gpt-3.5-turbo-instruct",
        prompt=f"Используй выход в интернет, Ищи информацию на русском языке, чтобы написать текст на 400 слов про {client_name} и их вклад в развитие искусственного интеллекта. В ответе пиши тнформацию ТОЛЬКО на русском языке!!! {text[:4000]}",
        max_tokens=3000,
        temperature=0.7,
        stop=None  # Отключаем генерацию текста после определенного символа
    )

    # Извлекаем переведенный текст из ответа GPT
    translated_text = response.choices[0].text.strip()
    
    # Удаляем текст после последней точки
    translated_text = translated_text.rsplit('.', 1)[0] + '.'

    # Заменяем символы [] на ()
    translated_text = translated_text.replace('[', '(').replace(']', ')')

    return translated_text
    sleep [2]

# Пример использования
file_path = 'urls_to_parse.txt'
urls_to_parse = read_urls_from_file(file_path)
parse_client_info(urls_to_parse)
